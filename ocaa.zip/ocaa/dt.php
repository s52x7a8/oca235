<?php
$apibot = "5768421713:AAH87W_oOWwuSsj5LqoxJyUACDnDslQVO_c"; 
$canal = "-894957261";

?>