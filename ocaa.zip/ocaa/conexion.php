<?php
$servername = "sql304.epizy.com";
$username = "epiz_32716702";
$password = "atytgwnoY7wI0";
$dbname   = "epiz_32716702_message";
$dbServerPort = "3306";





// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $dbServerPort);


?>